const express = require("express")
const app = express()

app.set('view engine', 'ejs')

app.use(express.static('public'))

app.get("/", (req, res) => {
    res.render('index')
})

app.get("/clientes", (req, res) => {
    let clientes = [
            { foto: "", nome: "Thiago Funaki", cpf: "320.584.797-32", endereco: "Registro" },
            { foto: "", nome: "Raphael Pedretti", cpf: "456.123.789-10", endereco: "Registro" },
            { foto: "", nome: "Renato Valente", cpf: "789.456.123-32", endereco: "Registro" },
            { foto: "", nome: "Pedro Xavier", cpf: "147.369.258-01", endereco: "Registro" },
            { foto: "", nome: "Vinicius Arai", cpf: "852.741.963-00", endereco: "Registro" },
            { foto: "", nome: "Davi Mathais", cpf: "963.258.741-32", endereco: "Registro" }
    ];
    res.render('clientes', {
        clientes: clientes
    })
})


app.get("/produtos", (req, res) => {
    let produtos = [
            { foto: "", nome: 'Notebook DELL', preco: 3500, categoria: 'Eletrônicos' },
            { foto: "", nome: 'Notebook SAMSUNG', preco: 4010, categoria: 'Eletrônicos' },
            { foto: "", nome: 'Notebook ACER', preco: 5198, categoria: 'Eletrônicos' },
            { foto: "", nome: 'Notebook ASUS', preco: 3600, categoria: 'Eletrônicos' },
            { foto: "", nome: 'Notebook LENOVO', preco: 4999, categoria: 'Eletrônicos' },
            { foto: "", nome: 'Notebook VAIO', preco: 4760, categoria: 'Eletrônicos' }
    ];
    res.render('produtos', {
        produtos: produtos
    })
})


app.get("/pedidos", (req, res) => {
    let pedidos = [
        { foto: "", numero: "13456", valor: 3500 },
        { foto: "", numero: "47698", valor: 4010 },
        { foto: "", numero: "86489", valor: 5198 },
        { foto: "", numero: "64680", valor: 3600 },
        { foto: "", numero: "73041", valor: 4999 },
        { foto: "", numero: "59412", valor: 4760 }
    ];
    res.render('pedidos', {
        pedido: pedidos
    });
});




app.listen(8080, function (erro) {
    if (erro) {
        console.log("Ocorreu um erro!")
    } else {
        console.log("Servidor iniciado com sucesso!")
    }

})